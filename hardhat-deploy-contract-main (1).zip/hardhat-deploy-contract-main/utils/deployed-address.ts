const deployedAddress = ''

export default deployedAddress
